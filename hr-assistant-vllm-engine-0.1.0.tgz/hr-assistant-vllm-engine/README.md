# hr-assistant-vllm-engine

SUSE vLLM serving engine (GPU) for the HR Assistant. Serves the model over the OpenAI API; the router component in front of it discovers it by label.

This chart is one component of the `hr-assistant-vllm` SUSE AI Factory blueprint (`catalog/blueprints/hr-assistant-vllm-1-3-0.yaml`). It vendors `charts/hr-assistant-vllm` (alias `hr`) and enables only this workload. See `charts/hr-assistant-vllm/README.md` for the full component list, how the components connect, and how to install the blueprint.
