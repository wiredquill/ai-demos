import{U as a,C as n}from"./mermaid.core.B5XgOHfJ.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.BUv_vAX2.js.map
