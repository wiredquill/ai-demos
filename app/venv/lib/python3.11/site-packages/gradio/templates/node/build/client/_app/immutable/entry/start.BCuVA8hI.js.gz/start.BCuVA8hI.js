import{s as t}from"../chunks/client.BvoDdlk9.js";export{t as start};
//# sourceMappingURL=start.BCuVA8hI.js.map
