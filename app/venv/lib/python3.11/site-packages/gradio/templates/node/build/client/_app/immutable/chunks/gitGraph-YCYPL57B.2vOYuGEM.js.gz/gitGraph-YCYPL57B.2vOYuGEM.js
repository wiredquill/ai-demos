import{G as a,f as G}from"./mermaid-parser.core.C22uIpNU.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-YCYPL57B.2vOYuGEM.js.map
