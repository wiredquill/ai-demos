import{Y as e,_ as n}from"../chunks/2.BTedhIeN.js";export{e as component,n as universal};
//# sourceMappingURL=2.Bq6VcBeW.js.map
