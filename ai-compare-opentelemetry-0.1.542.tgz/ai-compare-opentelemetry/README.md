# AI Compare - SUSE Edition

![SUSE Logo](https://raw.githubusercontent.com/SUSE/awesome-suse/main/assets/SUSE-logo.png)

## Overview

**AI Compare SUSE Edition** is a comprehensive AI response comparison tool built specifically for SUSE environments. Demonstrates differences between direct model access and pipeline-enhanced responses while showcasing SUSE's complete cloud-native stack including observability, security, and enterprise container technologies.

## 🏗️ Enterprise Architecture

This chart deploys a complete AI comparison stack optimized for SUSE environments with four main components:

### 🦙 Ollama - Enterprise LLM Server
- **Purpose**: Local large language model inference
- **Base Image**: SUSE BCI (Base Container Images)
- **Enterprise Features**: Enhanced security, SUSE support lifecycle
- **Models**: TinyLlama, Llama2, optimized for SUSE infrastructure

### 🌐 Open WebUI - SUSE-Optimized Web Interface
- **Purpose**: Modern web interface for LLM interactions
- **Base Image**: SUSE Application Collection
- **Enterprise Features**: SUSE registry integration, vulnerability scanning
- **Security**: Container hardening with SUSE security standards

### 🔗 Open WebUI Pipelines - Enterprise Pipeline Framework
- **Purpose**: Middleware for response processing and enhancement
- **Base Image**: SUSE Python runtime with zypper package management
- **Features**: Educational response levels, enterprise API integration
- **SUSE Integration**: Native observability and security hooks

### 🐍 AI Compare Chat - SUSE-Native Comparison App
- **Purpose**: Side-by-side AI response comparison with SUSE integrations
- **Base Image**: SUSE BCI Python with enterprise tooling
- **SUSE Features**: Native SUSE Observability, NeuVector DLP integration
- **Security**: SUSE security demos and monitoring integration

## ✨ SUSE-Specific Features

### 🔒 **SUSE Security Integration**
- **Enhanced NeuVector DLP**: Automated data loss prevention with dual-pattern detection
- **Advanced Security Demos**:
  - Credit Card pattern: `3412-1234-1234-2222`
  - Social Security Number: `123-45-6789`
  - Single-button multi-data type transmission testing
- **Container Security**: SUSE BCI hardened container images
- **Vulnerability Management**: Integrated with SUSE security stack

### 📊 **SUSE Observability**
- **Native Integration**: Built-in SUSE Observability support
- **OpenTelemetry**: Pre-configured for SUSE Observability collector
- **GPU Monitoring**: NVIDIA integration with SUSE GPU Operator
- **Custom Dashboards**: SUSE-specific monitoring templates

### 🚀 **SUSE Platform Optimization**
- **Rancher Integration**: Optimized for Rancher deployment
- **SUSE Registry**: Native integration with SUSE container registry
- **Enterprise Support**: Backed by SUSE enterprise support lifecycle
- **Air-Gapped Support**: Compatible with disconnected SUSE environments

### 🔧 **SUSE Management Tools**
- **Longhorn Storage**: Integrated persistent storage
- **Fleet GitOps**: Automated deployment via SUSE Fleet
- **Harvester Integration**: Optimized for SUSE Harvester HCI
- **Edge Deployment**: SUSE Edge computing ready

## 🚀 SUSE Quick Start

1. **Install from SUSE Rancher Apps & Marketplace**
   - Navigate to Apps & Marketplace in Rancher
   - Search for "AI Compare SUSE"
   - Select SUSE-optimized variant

2. **SUSE-Specific Configuration**
   - **NeuVector**: Enable automatic DLP policy deployment
   - **SUSE Observability**: Configure OpenTelemetry endpoint
   - **GPU Operator**: Enable NVIDIA GPU support via SUSE GPU Operator
   - **Longhorn Storage**: Configure persistent storage

3. **Enterprise Access**
   - AI Compare Chat with SUSE branding and security
   - SUSE Observability dashboards and monitoring
   - NeuVector security policy management

## 📋 SUSE Prerequisites

- **SUSE Rancher**: v2.6+ (recommended v2.8+)
- **Kubernetes**: SUSE-supported version (RKE2 recommended)
- **SUSE Observability**: For full monitoring integration
- **NeuVector**: For security demonstration features
- **SUSE GPU Operator**: For GPU acceleration (optional)
- **Longhorn**: For persistent storage (recommended)

## ⚙️ SUSE Enterprise Configuration

### Core SUSE Settings
- **Registry Integration**: SUSE container registry configuration
- **Image Pull Policy**: Enterprise registry authentication
- **Resource Management**: SUSE-optimized resource allocation
- **Network Policies**: NeuVector-compatible networking

### SUSE Observability Integration
```yaml
aiCompare:
  observability:
    enabled: true
    # Leave empty to auto-discover the shared OpenTelemetry collector at
    # install time (Helm lookup in the 'observability'/'suse-observability'
    # namespaces). Set an explicit URL only to override discovery.
    otlpEndpoint: ""
    collectGpuStats: true
```

The OTLP endpoint is **auto-discovered** rather than hardcoded, so the chart
works on any cluster: a fresh install points telemetry at that cluster's own
collector. Discovery matches the OpenTelemetry operator's standard labels
(`app.kubernetes.io/component=opentelemetry-collector`) and the OTLP ports, so
it works whether the collector is named `ai-observability-collector`,
`opentelemetry-collector`, or anything else. If discovery finds nothing, the
chart falls back to the conventional
`opentelemetry-collector.observability.svc.cluster.local` name rather than
silently pointing at a cluster that no longer exists.

#### Pre-install check: "can we even find a collector?"

Installing with telemetry enabled but no reachable collector is a silent
failure: the app looks healthy while every span is dropped and the
span-duration monitors quietly go stale. To catch that **before** the install
rather than days later, the chart validates discovery during
install/upgrade:

```bash
helm install ai-compare ./charts/ai-compare-opentelemetry -n ai-compare --dry-run=server
```

If no collector can be found (and no explicit `otlpEndpoint` is set), the
install **stops** with an actionable message explaining the three ways out —
install the collector first, set `aiCompare.observability.otlpEndpoint`, or
accept degraded telemetry via `observability.requireCollector=false`.

When discovery succeeds (or an explicit endpoint is set), `NOTES.txt` reports
the resolved endpoint after install, so the operator can see at a glance which
collector telemetry is going to.

Notes:
- Use `--dry-run=server` (not plain `--dry-run`) — only the server-side
  dry-run executes `lookup`, so it is the true pre-install test.
- Offline renders (`helm template`, CI linting) skip the check automatically,
  so pipelines keep working without a cluster.
- Escape hatch: `--set observability.requireCollector=false` installs anyway
  and prints a warning in `NOTES.txt` instead of failing.

#### Span-duration health checks (optional, per-app)

SUSE Observability ships "Span duration" monitors with a **5 s** default
threshold. LLM inference routinely exceeds 5 s, which raises false-positive
DEVIATING states. This chart can override the threshold **for this app's
objects only**, leaving the stock 5 s threshold in force for every other
workload on the cluster:

```yaml
observability:
  spanDuration:
    enabled: true
    thresholdMilliseconds: 15000   # default 5000
```

This works by rendering SUSE Observability's per-object monitor-override
annotations (`monitor.kubernetes-v2.stackstate.io/k8s-service-span-duration`
and `.../pod-span-duration`) onto this release's Services and Pod templates,
so the override travels with the install and cannot affect other apps. Set
`enabled: false` to keep the stock 5 s threshold.

**Not covered:** "Span duration for OpenTelemetry service instances". That
monitor targets a telemetry URN (`urn:opentelemetry:...`), not a Kubernetes
object, so no per-object annotation can reach it; tune it globally in SUSE
Observability if needed.


### NeuVector Security Integration
```yaml
neuvector:
  enabled: true
  controllerUrl: "https://neuvector-svc-controller.neuvector.svc.cluster.local:10443"
  dlpPolicies: true
  securityDemos: true
```

### SUSE GPU Support
```yaml
ollama:
  gpu:
    enabled: true
    type: nvidia
    suseGpuOperator: true
```

## 🛡️ SUSE Security & Compliance

- **Container Security**: SUSE BCI hardened base images
- **Vulnerability Scanning**: Integrated with SUSE security scanning
- **Enhanced DLP Compliance**: NeuVector multi-pattern data loss prevention automation
- **Access Control**: SUSE-compatible RBAC and security policies
- **Audit Logging**: Full integration with SUSE audit frameworks

## 📈 SUSE Monitoring Stack

- **SUSE Observability**: Full-stack observability platform
- **GPU Metrics**: NVIDIA monitoring via SUSE GPU Operator
- **Application Metrics**: Custom AI/ML performance indicators
- **Security Metrics**: NeuVector integration for security monitoring
- **Business Metrics**: Usage analytics and cost optimization

## 🏢 Enterprise Support

- **SUSE Support**: Enterprise support through SUSE channels
- **Professional Services**: SUSE consulting and implementation services
- **Training**: SUSE Academy training modules for AI/ML on SUSE
- **Community**: SUSE Community forums and resources

## 🔧 SUSE Customization

Enterprise-grade customization options:

```yaml
# SUSE Enterprise Registry
image:
  registry: "registry.suse.com"
  pullPolicy: "Always"
  pullSecrets: ["suse-registry-secret"]

# SUSE Observability
suseObservability:
  enabled: true
  namespace: "suse-observability"
  collector: "opentelemetry-collector"

# Enterprise Storage
persistence:
  storageClass: "longhorn"
  size: "100Gi"
  backup: true
```

## 🚀 SUSE Cloud-Native Stack

Perfect integration with the complete SUSE cloud-native portfolio:

- **🚢 SUSE Rancher**: Container management platform
- **📊 SUSE Observability**: Full-stack observability
- **🛡️ NeuVector**: Container security platform
- **💾 Longhorn**: Cloud-native distributed storage
- **🚀 Fleet**: GitOps continuous delivery
- **🖥️ Harvester**: Hyper-converged infrastructure
- **⚡ SUSE Edge**: Edge computing platform

## 📚 SUSE Documentation & Resources

- **SUSE Documentation**: [Official SUSE docs](https://documentation.suse.com/)
- **Rancher Documentation**: [Rancher docs](https://rancher.com/docs/)
- **NeuVector Documentation**: [NeuVector docs](https://docs.neuvector.com/)
- **SUSE Observability**: [Observability docs](https://docs.suse.com/suse-observability/)
- **Community**: [SUSE Community](https://community.suse.com/)

## 🏷️ SUSE Version Information

- **Chart Version**: 0.1.144
- **App Version**: 1.0.0
- **SUSE BCI Version**: Latest LTS
- **Rancher Compatibility**: 2.6+
- **Kubernetes Compatibility**: SUSE-supported versions

---

*Enterprise-ready AI comparison platform powered by SUSE's complete cloud-native stack. Built for security, observability, and enterprise scale.*

![SUSE Certified](https://img.shields.io/badge/SUSE-Certified-brightgreen)
![Enterprise Ready](https://img.shields.io/badge/Enterprise-Ready-blue)
![Cloud Native](https://img.shields.io/badge/Cloud%20Native-CNCF-purple)
