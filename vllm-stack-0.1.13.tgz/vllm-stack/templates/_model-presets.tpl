{{/*
Model presets for the install form (added by the wiredquill-ai-demos republish,
catalog/charts/vllm-stack/model-presets.patch).

A modelSpec entry with `preset: <name>` gets that preset's model and engine
arguments. Keys under a preset's `auto:` are only defaults: they fill fields the
form left empty or set to "auto", so GPU count, memory, context length and GPU
memory fraction can still be overridden. `preset: custom` (or no preset) leaves
the entry as written, the upstream behaviour.

After the preset, for every entry:
  - servedModelName (if set) is passed as --served-model-name, overriding the
    preset's name;
  - extraArgsText (one argument per line) is appended to vllmConfig.extraArgs,
    so it wins over the preset (vLLM keeps the last occurrence of a flag);
  - vllmConfig.tensorParallelSize follows requestGPU.
*/}}
{{- define "vllmstack.resolveModelSpec" -}}
{{- $spec := deepCopy .spec -}}
{{- $name := toString (default "custom" $spec.preset) -}}
{{- if ne $name "custom" -}}
  {{- $presets := include "vllmstack.modelPresets" . | fromYaml -}}
  {{- if not (hasKey $presets $name) -}}
    {{- fail (printf "unknown model preset %q (choose one from the install form, or \"custom\")" $name) -}}
  {{- end -}}
  {{- $p := deepCopy (index $presets $name) -}}
  {{- $auto := default (dict) $p.auto -}}
  {{- range $k, $v := $auto -}}
    {{- if eq $k "vllmConfig" -}}
      {{- $cfg := default (dict) $spec.vllmConfig -}}
      {{- range $k2, $v2 := $v -}}
        {{- if or (not (hasKey $cfg $k2)) (eq (toString (index $cfg $k2)) "") (eq (toString (index $cfg $k2)) "auto") -}}
          {{- $_ := set $cfg $k2 $v2 -}}
        {{- end -}}
      {{- end -}}
      {{- $_ := set $spec "vllmConfig" $cfg -}}
    {{- else if or (not (hasKey $spec $k)) (eq (toString (index $spec $k)) "") (eq (toString (index $spec $k)) "auto") -}}
      {{- $_ := set $spec $k $v -}}
    {{- end -}}
  {{- end -}}
  {{- $spec = mergeOverwrite $spec (omit $p "auto") -}}
{{- end -}}
{{- /* "custom" model with fields left at auto */ -}}
{{- range $k, $v := dict "requestMemory" "16Gi" "limitMemory" "64Gi" "shmSize" "16Gi" -}}
  {{- if and (hasKey $spec $k) (eq (toString (index $spec $k)) "auto") -}}
    {{- $_ := set $spec $k $v -}}
  {{- end -}}
{{- end -}}
{{- $cfg := default (dict) $spec.vllmConfig -}}
{{- $args := default (list) $cfg.extraArgs -}}
{{- with $spec.servedModelName -}}
  {{- if ne (toString .) "auto" -}}
    {{- $args = concat $args (list "--served-model-name" (toString .)) -}}
  {{- end -}}
{{- end -}}
{{- with $spec.extraArgsText -}}
  {{- range splitList "\n" (toString .) -}}
    {{- $a := trim . -}}
    {{- if $a -}}{{- $args = append $args $a -}}{{- end -}}
  {{- end -}}
{{- end -}}
{{- $_ := set $cfg "extraArgs" $args -}}
{{- if eq (toString (default "" $spec.requestGPU)) "auto" -}}
  {{- $_ := set $spec "requestGPU" 1 -}}
{{- end -}}
{{- $_ := set $cfg "tensorParallelSize" (int (default 1 $spec.requestGPU)) -}}
{{- range $k := list "maxModelLen" "gpuMemoryUtilization" "maxNumSeqs" -}}
  {{- if and (hasKey $cfg $k) (has (toString (index $cfg $k)) (list "" "auto")) -}}
    {{- $_ := unset $cfg $k -}}
  {{- end -}}
{{- end -}}
{{- $_ := set $spec "vllmConfig" $cfg -}}
{{- toYaml $spec -}}
{{- end -}}

{{/*
The presets. served model names are what clients (Hermes, LiteLLM, Open WebUI)
put in "model". Memory figures are for the engine pod's CPU RAM; on unified
memory systems (DGX Spark / GB10) they cover the model too.
*/}}
{{- define "vllmstack.modelPresets" -}}
# --- Hermes on DGX Spark (dgx-spark-fleet vllm-node) -------------------------
# The same model, name, context and parsers as vllm-node, without the two flags
# that need a custom vLLM build (DFlash speculative decoding, instanttensor).
hermes-qwen3.8-27b-nvfp4:
  modelURL: RadixArk/Qwen3.8-27B-NVFP4
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - qwen3.8-27b
      - --trust-remote-code
      - --kv-cache-dtype
      - fp8
      - --max-num-batched-tokens
      - "16384"
      - --async-scheduling
      - --reasoning-parser
      - qwen3
      - --enable-auto-tool-choice
      - --tool-call-parser
      - qwen3_xml
  auto:
    requestGPU: 1
    requestMemory: 80Gi
    limitMemory: 112Gi
    shmSize: 64Gi
    vllmConfig:
      maxModelLen: 262144
      maxNumSeqs: 8
      gpuMemoryUtilization: 0.6
# vllm-node exactly, including DFlash speculative decoding and instanttensor
# loading. Needs an engine image whose vLLM has both.
hermes-qwen3.8-27b-nvfp4-dflash:
  modelURL: RadixArk/Qwen3.8-27B-NVFP4
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - qwen3.8-27b
      - --trust-remote-code
      - --kv-cache-dtype
      - fp8
      - --max-num-batched-tokens
      - "16384"
      - --async-scheduling
      - --speculative-config
      - '{"method":"dflash","model":"z-lab/Qwen3.8-27B-DFlash2","num_speculative_tokens":8,"draft_tensor_parallel_size":1}'
      - --load-format
      - instanttensor
      - --reasoning-parser
      - qwen3
      - --enable-auto-tool-choice
      - --tool-call-parser
      - qwen3_xml
  auto:
    requestGPU: 1
    requestMemory: 80Gi
    limitMemory: 112Gi
    shmSize: 64Gi
    vllmConfig:
      maxModelLen: 262144
      maxNumSeqs: 8
      gpuMemoryUtilization: 0.6
# --- Qwen ----------------------------------------------------------------------
qwen3-4b-instruct-2507:
  modelURL: Qwen/Qwen3-4B-Instruct-2507
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - qwen3-4b
      - --enable-auto-tool-choice
      - --tool-call-parser
      - hermes
  auto:
    requestGPU: 1
    requestMemory: 8Gi
    limitMemory: 24Gi
    shmSize: 8Gi
    vllmConfig:
      maxModelLen: 65536
      gpuMemoryUtilization: 0.9
qwen3.6-35b-a3b:
  modelURL: Qwen/Qwen3.6-35B-A3B
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - qwen3.6-35b-a3b
      - --kv-cache-dtype
      - fp8
      - --reasoning-parser
      - qwen3
      - --enable-auto-tool-choice
      - --tool-call-parser
      - qwen3_xml
  auto:
    requestGPU: 1
    requestMemory: 32Gi
    limitMemory: 96Gi
    shmSize: 16Gi
    vllmConfig:
      maxModelLen: 131072
      gpuMemoryUtilization: 0.9
# --- Gemma 4 -------------------------------------------------------------------
gemma-4-e4b-it:
  modelURL: google/gemma-4-E4B-it
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - gemma-4-e4b
      - --reasoning-parser
      - gemma4
      - --enable-auto-tool-choice
      - --tool-call-parser
      - gemma4
  auto:
    requestGPU: 1
    requestMemory: 12Gi
    limitMemory: 32Gi
    shmSize: 8Gi
    vllmConfig:
      maxModelLen: 65536
      gpuMemoryUtilization: 0.9
gemma-4-26b-a4b-it:
  modelURL: google/gemma-4-26B-A4B-it
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - gemma-4-26b-a4b
      - --kv-cache-dtype
      - fp8
      - --reasoning-parser
      - gemma4
      - --enable-auto-tool-choice
      - --tool-call-parser
      - gemma4
  auto:
    requestGPU: 1
    requestMemory: 32Gi
    limitMemory: 80Gi
    shmSize: 16Gi
    vllmConfig:
      maxModelLen: 131072
      gpuMemoryUtilization: 0.9
gemma-4-31b-it-fp8:
  modelURL: RedHatAI/gemma-4-31B-it-FP8-dynamic
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - gemma-4-31b
      - --kv-cache-dtype
      - fp8
      - --reasoning-parser
      - gemma4
      - --enable-auto-tool-choice
      - --tool-call-parser
      - gemma4
  auto:
    requestGPU: 1
    requestMemory: 32Gi
    limitMemory: 64Gi
    shmSize: 16Gi
    vllmConfig:
      maxModelLen: 65536
      gpuMemoryUtilization: 0.9
gemma-4-31b-it-nvfp4:
  modelURL: nvidia/gemma-4-31B-it-NVFP4
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - gemma-4-31b
      - --kv-cache-dtype
      - fp8
      - --async-scheduling
      - --reasoning-parser
      - gemma4
      - --enable-auto-tool-choice
      - --tool-call-parser
      - gemma4
  auto:
    requestGPU: 1
    requestMemory: 64Gi
    limitMemory: 112Gi
    shmSize: 32Gi
    vllmConfig:
      maxModelLen: 131072
      gpuMemoryUtilization: 0.6
# --- gpt-oss -------------------------------------------------------------------
gpt-oss-20b:
  modelURL: openai/gpt-oss-20b
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - gpt-oss-20b
      - --reasoning-parser
      - openai_gptoss
      - --enable-auto-tool-choice
      - --tool-call-parser
      - openai
  auto:
    requestGPU: 1
    requestMemory: 16Gi
    limitMemory: 32Gi
    shmSize: 8Gi
    vllmConfig:
      maxModelLen: 131072
      gpuMemoryUtilization: 0.9
gpt-oss-120b:
  modelURL: openai/gpt-oss-120b
  vllmConfig:
    enableChunkedPrefill: true
    enablePrefixCaching: true
    extraArgs:
      - --served-model-name
      - gpt-oss-120b
      - --reasoning-parser
      - openai_gptoss
      - --enable-auto-tool-choice
      - --tool-call-parser
      - openai
  auto:
    requestGPU: 1
    requestMemory: 64Gi
    limitMemory: 112Gi
    shmSize: 32Gi
    vllmConfig:
      maxModelLen: 131072
      gpuMemoryUtilization: 0.9
# --- Embeddings (Hermes / Honcho memory) -----------------------------------------
# dgx-spark-fleet honcho-embed: nomic-embed-text-v1, small context, ~8% of the GPU.
nomic-embed-text-v1:
  modelURL: nomic-ai/nomic-embed-text-v1
  vllmConfig:
    runner: pooling
    enablePrefixCaching: false
    extraArgs:
      - --served-model-name
      - nomic-embed-text-v1
      - --trust-remote-code
  auto:
    requestGPU: 1
    requestMemory: 2Gi
    limitMemory: 8Gi
    shmSize: 2Gi
    vllmConfig:
      maxModelLen: 512
      gpuMemoryUtilization: 0.08
{{- end -}}
